# Speed Translate 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Akshay-Mandal/pen/vEBGgjV](https://codepen.io/Akshay-Mandal/pen/vEBGgjV).

